from matematika.geometri2D import luasPersegiPanjang

#persegi panjang
p = 10
l = 8

luas = luasPersegiPanjang(p, l)

print("Persegi Panjang")
print("Panjang\t:", p)
print("Lebar\t:", l)
print("Luas\t:", luas)