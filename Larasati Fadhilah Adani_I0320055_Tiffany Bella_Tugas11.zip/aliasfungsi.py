from matematika.geometri2D import luasPersegiPanjang as lpp

#persegi panjang
p = 10
l = 8

luas = lpp(p, l)

print("Persegi Panjang")
print("Panjang\t:", p)
print("Lebar\t:", l)
print("Luas\t:", luas)